import React, { useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { ArrowLeft, IndianRupee, Clock, TrendingUp, AlertTriangle, Lightbulb, ShieldAlert, HelpCircle } from "lucide-react";
import { useProject, useProjectUpdates, useRiskAssessment, useEarlyWarnings } from "@/hooks/useData";
import RiskBadge from "@/components/ui/RiskBadge";
import SectionCard from "@/components/ui/SectionCard";
import { formatCurrency, formatPercent } from "@/lib/format";

const AXIS = { fill: "#94a3b8", fontSize: 11 };
const GRID = "rgba(255,255,255,0.06)";
const TOOLTIP_STYLE = { background: "#111a2e", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8, color: "#e2e8f0", fontSize: 12 };

function RiskGauge({ label, value }) {
  const color = value >= 70 ? "#ef4444" : value >= 45 ? "#f59e0b" : "#10b981";
  return (
    <div className="text-center">
      <div className="relative w-24 h-24 mx-auto">
        <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
          <circle cx="18" cy="18" r="15" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="3" />
          <circle cx="18" cy="18" r="15" fill="none" stroke={color} strokeWidth="3" strokeDasharray={`${value * 0.94} 100`} strokeLinecap="round" />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center text-xl font-bold text-slate-100">{value}</div>
      </div>
      <div className="text-xs text-slate-400 mt-1">{label}</div>
    </div>
  );
}

function Metric({ label, value, sub, accent = "text-slate-100" }) {
  return (
    <div className="bg-[#111a2e] rounded-xl border border-white/10 p-3">
      <div className="text-[11px] text-slate-400 uppercase tracking-wide">{label}</div>
      <div className={`text-lg font-bold mt-1 ${accent}`}>{value}</div>
      {sub && <div className="text-[11px] text-slate-500 mt-0.5">{sub}</div>}
    </div>
  );
}

export default function ProjectDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: project, isLoading } = useProject(id);
  const { data: updates = [] } = useProjectUpdates(id);
  const { data: assessment } = useRiskAssessment(id);
  const { data: warnings = [] } = useEarlyWarnings(id);

  const projectWarnings = useMemo(() => warnings.filter(w => w.project_id === id), [warnings, id]);

  const latest = updates[updates.length - 1] || null;
  const expectedProgress = latest?.planned_progress ?? project?.financial_progress ?? 0;

  const chartData = useMemo(() => updates.map(u => ({
    date: u.date.slice(5),
    Expected: u.planned_progress,
    Actual: u.actual_progress,
    PlannedExp: u.planned_expenditure,
    ActualExp: u.actual_expenditure,
  })), [updates]);

  const riskReasons = useMemo(() => {
    if (!project) return [];
    const reasons = [];
    if (project.physical_progress < expectedProgress) {
      reasons.push(`Physical progress (${formatPercent(project.physical_progress)}) is below expected progress (${formatPercent(expectedProgress)}).`);
    }
    if (project.time_overrun_months > 6) {
      reasons.push("Important milestones are delayed.");
    }
    if (project.expenditure > project.revised_cost * 0.9) {
      reasons.push("Expenditure is higher than expected relative to revised cost.");
    }
    if (project.time_overrun_months > 12) {
      reasons.push("Project timeline is under pressure.");
    }
    if (project.cost_overrun / project.original_cost > 0.3) {
      reasons.push("Cost has escalated significantly beyond the original estimate.");
    }
    if (reasons.length === 0) reasons.push("No major risk signals detected — project is tracking within expected parameters.");
    return reasons;
  }, [project, expectedProgress]);

  if (isLoading || !project) return <div className="flex items-center justify-center h-96"><div className="w-8 h-8 border-4 border-white/10 border-t-blue-500 rounded-full animate-spin" /></div>;

  const costVariance = project.revised_cost - project.original_cost;
  const costVariancePct = Math.round((costVariance / project.original_cost) * 100);
  const delayMonths = project.time_overrun_months;
  const milestonesTotal = updates.length || 1;
  const milestonesCompleted = updates.filter(u => u.actual_progress >= u.planned_progress).length;

  const costRisk = assessment?.cost_risk ?? Math.min(100, Math.round((costVariancePct / 50) * 100));
  const delayRisk = assessment?.delay_risk ?? Math.min(100, Math.round((delayMonths / 24) * 100));
  const implRisk = assessment?.implementation_risk ?? Math.min(100, Math.round(100 - project.physical_progress));

  return (
    <div className="space-y-5">
      <button onClick={() => navigate("/projects")} className="inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-slate-200">
        <ArrowLeft size={16} /> Back to Projects
      </button>

      {/* Header */}
      <div className="bg-[#111a2e] rounded-xl border border-white/10 p-5">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-slate-400">{project.project_code}</span>
            </div>
            <h1 className="text-xl font-bold text-slate-100 mt-1">{project.name}</h1>
            <div className="flex flex-wrap gap-x-5 gap-y-1 mt-3 text-xs">
              <span><span className="text-slate-500">Sector:</span> <span className="text-slate-200">{project.sector}</span></span>
              <span><span className="text-slate-500">Department:</span> <span className="text-slate-200">{project.department || project.ministry}</span></span>
              <span><span className="text-slate-500">Location:</span> <span className="text-slate-200">{project.state}</span></span>
              <span><span className="text-slate-500">Status:</span> <span className="text-slate-200">{project.physical_progress >= 100 ? "Completed" : "In Progress"}</span></span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[11px] text-slate-400">AI Risk Score</div>
            <div className="text-3xl font-bold text-slate-100">{project.ai_risk_score}<span className="text-base text-slate-500">/100</span></div>
            <RiskBadge level={project.risk_level} />
          </div>
        </div>
      </div>

      {/* Overall Risk */}
      <SectionCard title="Overall Project Risk" subtitle="Composite risk breakdown">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <div className="text-center">
            <div className="relative w-28 h-28 mx-auto">
              <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                <circle cx="18" cy="18" r="15" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="3.5" />
                <circle cx="18" cy="18" r="15" fill="none" stroke={project.ai_risk_score >= 70 ? "#ef4444" : project.ai_risk_score >= 45 ? "#f59e0b" : "#10b981"} strokeWidth="3.5" strokeDasharray={`${project.ai_risk_score * 0.94} 100`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-bold text-slate-100">{project.ai_risk_score}</span>
                <span className="text-[10px] text-slate-500">/100</span>
              </div>
            </div>
            <div className="text-xs text-slate-400 mt-2">Overall Risk</div>
          </div>
          <RiskGauge label="Cost Overrun Risk" value={costRisk} />
          <RiskGauge label="Time Delay Risk" value={delayRisk} />
          <RiskGauge label="Implementation Risk" value={implRisk} />
        </div>
      </SectionCard>

      {/* Financial & Progress Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Metric label="Original Cost" value={formatCurrency(project.original_cost)} accent="text-slate-100" />
        <Metric label="Revised Cost" value={formatCurrency(project.revised_cost)} accent={costVariancePct > 30 ? "text-red-400" : "text-slate-100"} />
        <Metric label="Expenditure" value={formatCurrency(project.expenditure)} accent="text-slate-100" />
        <Metric label="Physical Progress" value={formatPercent(project.physical_progress)} accent="text-blue-400" />
        <Metric label="Expected Progress" value={formatPercent(expectedProgress)} accent="text-slate-300" />
        <Metric label="Planned Completion" value={project.original_completion} accent="text-slate-300" />
        <Metric label="Revised Completion" value={project.revised_completion} accent={delayMonths > 12 ? "text-red-400" : "text-slate-300"} />
        <Metric label="Milestones" value={`${milestonesCompleted} / ${milestonesTotal}`} sub={`${delayMonths} mo time overrun`} accent="text-slate-100" />
      </div>

      {/* Actual vs Expected Progress */}
      <SectionCard title="Actual Progress vs Expected Progress" subtitle="Physical progress trajectory (%)">
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={chartData} margin={{ left: -20, right: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
            <XAxis dataKey="date" tick={AXIS} />
            <YAxis domain={[0, 100]} tick={AXIS} />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Legend wrapperStyle={{ fontSize: 11, color: "#94a3b8" }} />
            <Line type="monotone" dataKey="Expected" stroke="#64748b" strokeDasharray="5 5" dot={false} />
            <Line type="monotone" dataKey="Actual" stroke="#3b82f6" strokeWidth={2} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </SectionCard>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Why is this project at risk? */}
        <SectionCard title="Why is this project at risk?" subtitle="Plain-language risk explanation">
          <ul className="space-y-2.5">
            {riskReasons.map((r, i) => (
              <li key={i} className="flex gap-2.5 text-sm text-slate-300 leading-relaxed">
                <AlertTriangle size={15} className="text-amber-400 shrink-0 mt-0.5" />
                <span>{r}</span>
              </li>
            ))}
          </ul>
        </SectionCard>

        {/* Recommended Action */}
        <SectionCard title="Recommended Action" subtitle="Suggested intervention">
          {assessment?.recommended_actions?.length ? (
            <div className="space-y-2">
              {assessment.recommended_actions.map((a, i) => (
                <div key={i} className="flex gap-2 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
                  <Lightbulb size={15} className="text-blue-400 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-300">{a}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex gap-2 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <Lightbulb size={15} className="text-blue-400 shrink-0 mt-0.5" />
              <span className="text-sm text-slate-300">Review delayed milestones and prioritize this project for closer monitoring.</span>
            </div>
          )}
          {projectWarnings.length > 0 && (
            <div className="mt-4 pt-3 border-t border-white/10">
              <div className="text-xs font-semibold text-slate-300 mb-2">Active Warnings ({projectWarnings.length})</div>
              <div className="space-y-1.5">
                {projectWarnings.map(w => (
                  <div key={w.id} className="text-xs flex items-center gap-2">
                    <RiskBadge level={w.severity} /> <span className="text-slate-400">{w.warning_type}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </SectionCard>
      </div>
    </div>
  );
}