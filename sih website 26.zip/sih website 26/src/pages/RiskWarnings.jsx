import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useProjects, useEarlyWarnings } from "@/hooks/useData";
import RiskBadge from "@/components/ui/RiskBadge";
import SectionCard from "@/components/ui/SectionCard";
import { riskColor } from "@/lib/format";

const WARNING_TYPES = ["Cost Overrun", "Schedule Delay", "Slow Progress", "Budget Deviation", "Milestone Slippage", "Deadline Revision", "Implementation Issue", "Data Anomaly"];
const selectCls = "px-2 py-1 text-xs bg-[#0d1424] border border-white/10 rounded-md text-slate-200 outline-none focus:border-blue-500/50";

export default function RiskWarnings() {
  const { data: projects = [] } = useProjects();
  const { data: warnings = [] } = useEarlyWarnings();
  const navigate = useNavigate();
  const [sevFilter, setSevFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const counts = useMemo(() => {
    const c = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    warnings.forEach(w => c[w.severity] = (c[w.severity] || 0) + 1);
    return c;
  }, [warnings]);

  const filtered = useMemo(() => warnings.filter(w =>
    (!sevFilter || w.severity === sevFilter) &&
    (!typeFilter || w.warning_type === typeFilter) &&
    (!statusFilter || w.status === statusFilter)
  ).sort((a, b) => { const order = { Critical: 0, High: 1, Medium: 2, Low: 3 }; return order[a.severity] - order[b.severity] || new Date(b.date) - new Date(a.date); }), [warnings, sevFilter, typeFilter, statusFilter]);

  const matrix = useMemo(() => {
    const grid = Array.from({ length: 5 }, () => Array(5).fill(0));
    const sevWeight = { Low: 1, Medium: 2, High: 3, Critical: 4 };
    projects.forEach(p => {
      const prob = Math.min(4, Math.floor(p.ai_risk_score / 20));
      const impact = sevWeight[p.risk_level] || 1;
      grid[impact][prob]++;
    });
    return grid;
  }, [projects]);

  const prioritized = useMemo(() => [...projects].sort((a, b) => b.ai_risk_score - a.ai_risk_score).slice(0, 10), [projects]);

  const cellColor = (v) => v === 0 ? "bg-white/[0.03]" : v <= 1 ? "bg-amber-500/20" : v <= 3 ? "bg-orange-500/30" : "bg-red-500/40";

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2">
        <h1 className="text-xl font-bold text-slate-100">Risk & Early Warnings</h1>
      </div>
      <p className="text-sm text-slate-400 -mt-3">Risk intelligence centre — proactive alerts and project prioritisation</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {["Critical", "High", "Medium", "Low"].map(s => (
          <div key={s} className={`rounded-xl p-4 border ${riskColor(s)}`}>
            <div className="text-xs font-medium uppercase tracking-wide opacity-80">{s} Warnings</div>
            <div className="text-2xl font-bold mt-1">{counts[s] || 0}</div>
          </div>
        ))}
      </div>

      <SectionCard title="Warning Feed" subtitle={`${filtered.length} warnings`}
        action={
          <div className="flex gap-1.5 flex-wrap">
            <select value={sevFilter} onChange={e => setSevFilter(e.target.value)} className={selectCls}>
              <option value="">All Severity</option>
              {["Critical", "High", "Medium", "Low"].map(s => <option key={s}>{s}</option>)}
            </select>
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} className={selectCls}>
              <option value="">All Types</option>
              {WARNING_TYPES.map(s => <option key={s}>{s}</option>)}
            </select>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className={selectCls}>
              <option value="">All Status</option>
              {["Active", "Acknowledged", "Resolved"].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        }
      >
        <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1">
          {filtered.map(w => (
            <div key={w.id} className="bg-[#0d1424] border border-white/10 rounded-lg p-4 hover:border-white/20 cursor-pointer" onClick={() => navigate(`/projects/${w.project_id}`)}>
              <div className="flex items-center gap-2 flex-wrap">
                <RiskBadge level={w.severity} />
                <span className="text-sm font-semibold text-slate-100">{w.warning_type}</span>
                <span className={`ml-auto text-[10px] px-1.5 py-0.5 rounded font-medium ${w.status === "Active" ? "bg-red-500/15 text-red-400" : w.status === "Acknowledged" ? "bg-blue-500/15 text-blue-400" : "bg-emerald-500/15 text-emerald-400"}`}>{w.status}</span>
              </div>
              <div className="mt-2 text-xs text-slate-300"><span className="text-slate-500">Project:</span> {w.project_name}</div>
              <div className="mt-1.5 text-xs text-slate-400 leading-relaxed">{w.description}</div>
              {w.recommended_action && (
                <div className="mt-2 flex gap-1.5 text-xs text-slate-300">
                  <span className="text-slate-500 shrink-0">Recommended Action:</span>
                  <span>{w.recommended_action}</span>
                </div>
              )}
              <div className="flex items-center justify-between mt-2 text-[11px] text-slate-500">
                <span>Confidence {w.confidence}%</span>
                <span>{w.date}</span>
              </div>
            </div>
          ))}
          {filtered.length === 0 && <div className="text-sm text-slate-500 text-center py-8">No warnings match filters</div>}
        </div>
      </SectionCard>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <SectionCard title="Probability vs Impact Matrix" subtitle="Project distribution by risk dimensions" className="lg:col-span-1">
          <div className="overflow-x-auto">
            <table className="text-xs mx-auto">
              <thead>
                <tr>
                  <th className="p-1"></th>
                  <th colSpan={5} className="text-center text-slate-400 font-medium pb-1">Probability →</th>
                </tr>
                <tr>
                  <th className="p-1 text-[10px] text-slate-500">Impact ↓</th>
                  {["Very Low", "Low", "Med", "High", "Very High"].map((l, i) => <th key={i} className="p-1 text-[10px] text-slate-500 font-normal">{l}</th>)}
                </tr>
              </thead>
              <tbody>
                {matrix.map((row, i) => (
                  <tr key={i}>
                    <td className="p-1 text-[10px] text-slate-500 font-medium">{["—", "Low", "Med", "High", "Critical"][i]}</td>
                    {row.map((v, j) => (
                      <td key={j} className="p-0.5">
                        <div className={`w-10 h-9 rounded flex items-center justify-center font-semibold text-slate-200 ${cellColor(v)}`}>{v || ""}</div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>

        <SectionCard title="Project Prioritisation" subtitle="Top 10 projects by AI risk score" className="lg:col-span-2">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-white/[0.03]">
                <tr className="text-left text-slate-400 border-b border-white/10">
                  <th className="py-2 px-3 font-semibold">#</th>
                  <th className="py-2 px-3 font-semibold">Project</th>
                  <th className="py-2 px-3 font-semibold">Sector</th>
                  <th className="py-2 px-3 font-semibold">Cost Overrun</th>
                  <th className="py-2 px-3 font-semibold">Delay (mo)</th>
                  <th className="py-2 px-3 font-semibold">Risk Score</th>
                  <th className="py-2 px-3 font-semibold">Level</th>
                </tr>
              </thead>
              <tbody>
                {prioritized.map((p, i) => (
                  <tr key={p.id} className="border-b border-white/5 hover:bg-white/5 cursor-pointer" onClick={() => navigate(`/projects/${p.id}`)}>
                    <td className="py-2 px-3 font-semibold text-slate-500">{i + 1}</td>
                    <td className="py-2 px-3 font-medium text-slate-200 max-w-[220px] truncate" title={p.name}>{p.name}</td>
                    <td className="py-2 px-3 text-slate-300">{p.sector}</td>
                    <td className="py-2 px-3 text-slate-300">+{Math.round((p.cost_overrun / p.original_cost) * 100)}%</td>
                    <td className="py-2 px-3 text-slate-300">{p.time_overrun_months}</td>
                    <td className="py-2 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-white/10 rounded-full overflow-hidden">
                          <div className={`h-full ${p.ai_risk_score >= 80 ? "bg-red-500" : p.ai_risk_score >= 60 ? "bg-orange-500" : p.ai_risk_score >= 30 ? "bg-amber-500" : "bg-emerald-500"}`} style={{ width: `${p.ai_risk_score}%` }} />
                        </div>
                        <span className="font-semibold text-slate-200">{p.ai_risk_score}</span>
                      </div>
                    </td>
                    <td className="py-2 px-3"><RiskBadge level={p.risk_level} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}