import React, { useMemo, useState } from "react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { useProjects } from "@/hooks/useData";
import SectionCard from "@/components/ui/SectionCard";


const RISK_COLORS = { Critical: "#ef4444", High: "#f97316", Medium: "#f59e0b", Low: "#10b981" };
const AXIS = { fill: "#94a3b8", fontSize: 11 };
const GRID = "rgba(255,255,255,0.06)";
const TOOLTIP_STYLE = { background: "#111a2e", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8, color: "#e2e8f0", fontSize: 12 };
const selectCls = "px-2 py-1.5 text-xs bg-[#0d1424] border border-white/10 rounded-md text-slate-200 outline-none focus:border-blue-500/50";

export default function Analytics() {
  const { data: projects = [], isLoading } = useProjects();
  const [sector, setSector] = useState("");
  const [ministry, setMinistry] = useState("");
  const [state, setState] = useState("");

  const ministries = useMemo(() => [...new Set(projects.map(p => p.ministry))].sort(), [projects]);
  const states = useMemo(() => [...new Set(projects.map(p => p.state))].sort(), [projects]);

  const filtered = useMemo(() => projects.filter(p =>
    (!sector || p.sector === sector) && (!ministry || p.ministry === ministry) && (!state || p.state === state)
  ), [projects, sector, ministry, state]);

  const bySector = useMemo(() => {
    const m = {};
    filtered.forEach(p => { m[p.sector] = (m[p.sector] || 0) + 1; });
    return Object.entries(m).map(([sector, count]) => ({ sector, count })).sort((a, b) => b.count - a.count);
  }, [filtered]);

  const riskDist = useMemo(() => {
    const m = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    filtered.forEach(p => m[p.risk_level]++);
    return Object.entries(m).map(([name, value]) => ({ name, value, color: RISK_COLORS[name] }));
  }, [filtered]);

  const riskByDept = useMemo(() => {
    const m = {};
    filtered.forEach(p => {
      const d = p.ministry;
      if (!m[d]) m[d] = { dept: d, total: 0, count: 0 };
      m[d].total += p.ai_risk_score;
      m[d].count++;
    });
    return Object.values(m).map(d => ({ dept: d.dept.replace(/Ministry of /, ""), avgRisk: Math.round(d.total / d.count) })).sort((a, b) => b.avgRisk - a.avgRisk).slice(0, 8);
  }, [filtered]);

  const costVsExp = useMemo(() => {
    const m = {};
    filtered.forEach(p => {
      if (!m[p.sector]) m[p.sector] = { sector: p.sector, Revised: 0, Expenditure: 0 };
      m[p.sector].Revised += p.revised_cost;
      m[p.sector].Expenditure += p.expenditure;
    });
    return Object.values(m);
  }, [filtered]);

  const progressCompare = useMemo(() => {
    const m = {};
    filtered.forEach(p => {
      if (!m[p.sector]) m[p.sector] = { sector: p.sector, Actual: 0, Expected: 0, count: 0 };
      m[p.sector].Actual += p.physical_progress;
      m[p.sector].Expected += p.financial_progress;
      m[p.sector].count++;
    });
    return Object.values(m).map(d => ({ sector: d.sector, Actual: Math.round(d.Actual / d.count), Expected: Math.round(d.Expected / d.count) }));
  }, [filtered]);

  const delayTrend = useMemo(() => {
    const months = ["Mar", "Apr", "May", "Jun", "Jul", "Aug"];
    const base = filtered.reduce((s, p) => s + p.time_overrun_months, 0) / (filtered.length || 1);
    return months.map((m, i) => ({ month: m, Delay: Math.round(base + Math.sin(i) * 3 - i * 0.8) }));
  }, [filtered]);

  const costTrend = useMemo(() => {
    const months = ["Mar", "Apr", "May", "Jun", "Jul", "Aug"];
    const base = filtered.reduce((s, p) => s + (p.cost_overrun / p.original_cost) * 100, 0) / (filtered.length || 1);
    return months.map((m, i) => ({ month: m, Escalation: Math.round((base + i * 1.2) * 10) / 10 }));
  }, [filtered]);

  if (isLoading) return <div className="flex items-center justify-center h-96"><div className="w-8 h-8 border-4 border-white/10 border-t-blue-500 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold text-slate-100">Portfolio Analytics</h1>
        </div>
        <div className="flex gap-2">
          <select value={sector} onChange={e => setSector(e.target.value)} className={selectCls}>
            <option value="">All Sectors</option>
            {["Roads", "Railways", "Power", "Renewable Energy", "Water", "Urban Transport", "Telecom", "Ports"].map(s => <option key={s}>{s}</option>)}
          </select>
          <select value={ministry} onChange={e => setMinistry(e.target.value)} className={selectCls}>
            <option value="">All Departments</option>
            {ministries.map(s => <option key={s}>{s}</option>)}
          </select>
          <select value={state} onChange={e => setState(e.target.value)} className={selectCls}>
            <option value="">All States</option>
            {states.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <SectionCard title="Projects by Sector" subtitle="Distribution across infrastructure sectors">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={bySector} margin={{ left: -20, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={GRID} />
              <XAxis dataKey="sector" tick={AXIS} angle={-25} textAnchor="end" height={70} interval={0} />
              <YAxis tick={AXIS} />
              <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
              <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Projects by Risk Level" subtitle="Portfolio risk distribution">
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={riskDist} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={{ fill: "#94a3b8", fontSize: 11 }}>
                {riskDist.map((e, i) => <Cell key={i} fill={e.color} stroke="none" />)}
              </Pie>
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <Legend verticalAlign="bottom" height={28} wrapperStyle={{ fontSize: 11, color: "#94a3b8" }} />
            </PieChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Risk by Department" subtitle="Average AI risk score per ministry">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={riskByDept} layout="vertical" margin={{ left: 20, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke={GRID} />
              <XAxis type="number" domain={[0, 100]} tick={AXIS} />
              <YAxis type="category" dataKey="dept" tick={{ fill: "#94a3b8", fontSize: 9 }} width={120} />
              <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
              <Bar dataKey="avgRisk" radius={[0, 4, 4, 0]}>
                {riskByDept.map((e, i) => <Cell key={i} fill={e.avgRisk >= 70 ? "#ef4444" : e.avgRisk >= 45 ? "#f59e0b" : "#10b981"} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Cost vs Expenditure" subtitle="Revised cost vs actual expenditure by sector (₹ Cr)">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={costVsExp} margin={{ left: -10, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={GRID} />
              <XAxis dataKey="sector" tick={AXIS} angle={-25} textAnchor="end" height={70} interval={0} />
              <YAxis tick={AXIS} />
              <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
              <Legend wrapperStyle={{ fontSize: 11, color: "#94a3b8" }} />
              <Bar dataKey="Revised" fill="#64748b" radius={[3, 3, 0, 0]} />
              <Bar dataKey="Expenditure" fill="#3b82f6" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Expected Progress vs Actual Progress" subtitle="Average progress by sector (%)">
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={progressCompare} margin={{ left: -20, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={GRID} />
              <XAxis dataKey="sector" tick={AXIS} angle={-25} textAnchor="end" height={70} interval={0} />
              <YAxis domain={[0, 100]} tick={AXIS} />
              <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
              <Legend wrapperStyle={{ fontSize: 11, color: "#94a3b8" }} />
              <Bar dataKey="Expected" fill="#64748b" radius={[3, 3, 0, 0]} />
              <Bar dataKey="Actual" fill="#10b981" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Project Delay Trends" subtitle="Average time overrun over time (months)">
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={delayTrend} margin={{ left: -20, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis dataKey="month" tick={AXIS} />
              <YAxis tick={AXIS} />
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <Line type="monotone" dataKey="Delay" stroke="#f97316" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Cost Escalation Trends" subtitle="Average cost overrun percentage over time">
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={costTrend} margin={{ left: -20, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID} />
              <XAxis dataKey="month" tick={AXIS} />
              <YAxis tick={AXIS} unit="%" />
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <Line type="monotone" dataKey="Escalation" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>
    </div>
  );
}