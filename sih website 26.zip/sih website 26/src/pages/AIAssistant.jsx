import React, { useState, useRef, useEffect } from "react";
import { Bot, Send, Sparkles, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import Logo from "@/components/Logo";

const SUGGESTED = [
  "Which projects are at high risk?",
  "Why is this project risky?",
  "Which project has the highest delay risk?",
  "Which sector has the most high-risk projects?",
  "Show projects with possible cost risk.",
  "Compare these two projects.",
];

function formatAnswer(text) {
  return text.split("\n").map((line, i) => {
    if (line.trim().startsWith("**Key Insight")) return <div key={i} className="flex gap-2 mt-2"><Sparkles size={14} className="text-blue-400 shrink-0 mt-0.5" /><span className="font-semibold text-slate-100" dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.+?)\*\*/g, "$1") }} /></div>;
    if (line.trim().startsWith("**Supporting Indicators")) return <div key={i} className="font-semibold text-slate-100 mt-2" dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.+?)\*\*/g, "$1") }} />;
    if (line.trim().startsWith("**Recommended Action")) return <div key={i} className="font-semibold text-slate-100 mt-2" dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.+?)\*\*/g, "$1") }} />;
    if (line.trim().startsWith("-") || line.trim().startsWith("•")) return <div key={i} className="text-sm text-slate-300 ml-4 leading-relaxed" dangerouslySetInnerHTML={{ __html: line.replace(/^[-•]\s*/, "").replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>") }} />;
    if (line.trim()) return <div key={i} className="text-sm text-slate-300 leading-relaxed" dangerouslySetInnerHTML={{ __html: line.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>") }} />;
    return null;
  });
}

export default function AIAssistant() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const ask = async (q) => {
    const question = q || input;
    if (!question.trim() || loading) return;
    setInput("");
    setMessages(m => [...m, { role: "user", content: question }]);
    setLoading(true);
    try {
      const res = await base44.functions.invoke("aiAssistant", { question });
      setMessages(m => [...m, { role: "assistant", content: res.data.answer }]);
    } catch (e) {
      setMessages(m => [...m, { role: "assistant", content: "Sorry, I couldn't process that request right now. Please try again.", error: true }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      <div className="flex items-center gap-3">
        <Logo size={36} />
        <div>
          <h1 className="text-xl font-bold text-slate-100">NIRIKSHAN AI Assistant</h1>
          <p className="text-sm text-slate-400">Ask questions about your projects</p>
        </div>
      </div>

      {messages.length === 0 && (
        <div className="bg-[#111a2e] rounded-xl border border-white/10 p-5">
          <p className="text-sm text-slate-300 leading-relaxed">
            Welcome. I can analyze your project portfolio to surface risks, cost overruns, delays and recommended actions.
            Try one of the questions below, or ask your own.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-4">
            {SUGGESTED.map(q => (
              <button key={q} onClick={() => ask(q)} className="text-left text-sm px-3 py-2.5 rounded-lg border border-white/10 bg-[#0d1424] hover:border-blue-500/40 hover:bg-blue-500/10 text-slate-200 transition-colors">
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="space-y-3">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
            {m.role === "assistant" && <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shrink-0"><Bot size={16} className="text-white" /></div>}
            <div className={`max-w-[80%] rounded-xl px-4 py-3 ${m.role === "user" ? "bg-blue-600 text-white" : "bg-[#111a2e] border border-white/10"}`}>
              {m.role === "user" ? <div className="text-sm">{m.content}</div> : (
                <div className={m.error ? "text-sm text-red-400 flex gap-2" : ""}>
                  {m.error ? <><AlertCircle size={15} className="shrink-0 mt-0.5" /> {m.content}</> : formatAnswer(m.content)}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center shrink-0"><Bot size={16} className="text-white" /></div>
            <div className="bg-[#111a2e] border border-white/10 rounded-xl px-4 py-3 flex items-center gap-2">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
              <span className="text-xs text-slate-400">Analyzing portfolio…</span>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      <div className="sticky bottom-0 pt-2">
        <form onSubmit={(e) => { e.preventDefault(); ask(); }} className="flex gap-2 bg-[#111a2e] border border-white/10 rounded-xl p-2 shadow-lg">
          <input value={input} onChange={e => setInput(e.target.value)} placeholder="Ask about risks, delays, cost overruns…" className="flex-1 px-3 py-2.5 text-sm bg-transparent text-slate-100 placeholder:text-slate-500 outline-none" />
          <button type="submit" disabled={loading || !input.trim()} className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-sm font-medium disabled:opacity-40 inline-flex items-center gap-1.5 transition-colors">
            <Send size={15} /> Send
          </button>
        </form>
        <p className="text-[10px] text-slate-500 text-center mt-1.5 px-4">
          AI insights are decision-support recommendations based on sample data and should be validated before operational decisions.
        </p>
      </div>
    </div>
  );
}