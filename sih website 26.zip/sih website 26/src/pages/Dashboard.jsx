import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { FolderKanban, ShieldAlert, AlertTriangle, Activity, IndianRupee, Clock, Search, ArrowUpDown } from "lucide-react";
import { useProjects, useEarlyWarnings } from "@/hooks/useData";
import KpiCard from "@/components/ui/KpiCard";
import RiskBadge from "@/components/ui/RiskBadge";
import SectionCard from "@/components/ui/SectionCard";
import { formatPercent } from "@/lib/format";

const RISK_COLORS = { Critical: "#ef4444", High: "#f97316", Medium: "#f59e0b", Low: "#10b981" };
const AXIS = { fill: "#94a3b8", fontSize: 11 };
const GRID = "rgba(255,255,255,0.06)";
const TOOLTIP_STYLE = { background: "#111a2e", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8, color: "#e2e8f0", fontSize: 12 };

export default function Dashboard() {
  const { data: projects = [], isLoading } = useProjects();
  const { data: warnings = [] } = useEarlyWarnings();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [sortKey, setSortKey] = useState("ai_risk_score");
  const [sortDir, setSortDir] = useState("desc");
  const [page, setPage] = useState(0);
  const pageSize = 8;

  const stats = useMemo(() => {
    const by = (lvl) => projects.filter(p => p.risk_level === lvl).length;
    const costRisk = projects.filter(p => p.cost_overrun / p.original_cost > 0.3).length;
    const delayRisk = projects.filter(p => p.time_overrun_months > 12).length;
    return { total: projects.length, critical: by("Critical"), high: by("High"), medium: by("Medium"), low: by("Low"), costRisk, delayRisk };
  }, [projects]);

  const riskPie = useMemo(() =>
    ["Critical", "High", "Medium", "Low"].map(l => ({ name: l, value: stats[l.toLowerCase()] || 0, color: RISK_COLORS[l] })).filter(d => d.value > 0), [stats]);

  const sectorRisk = useMemo(() => {
    const map = {};
    projects.forEach(p => {
      if (!map[p.sector]) map[p.sector] = { sector: p.sector, count: 0, score: 0 };
      map[p.sector].count++;
      map[p.sector].score += p.ai_risk_score;
    });
    return Object.values(map).map(d => ({ sector: d.sector, avgRisk: Math.round(d.score / d.count) })).sort((a, b) => b.avgRisk - a.avgRisk);
  }, [projects]);

  const filtered = useMemo(() => {
    let rows = projects.filter(p =>
      !search || p.name.toLowerCase().includes(search.toLowerCase()) || p.project_code.toLowerCase().includes(search.toLowerCase()) || p.sector.toLowerCase().includes(search.toLowerCase())
    );
    rows.sort((a, b) => {
      const av = a[sortKey], bv = b[sortKey];
      const r = typeof av === "number" ? av - bv : String(av).localeCompare(String(bv));
      return sortDir === "desc" ? -r : r;
    });
    return rows;
  }, [projects, search, sortKey, sortDir]);

  const paged = filtered.slice(page * pageSize, (page + 1) * pageSize);
  const totalPages = Math.ceil(filtered.length / pageSize);

  const toggleSort = (key) => {
    if (sortKey === key) setSortDir(d => d === "desc" ? "asc" : "desc");
    else { setSortKey(key); setSortDir("desc"); }
  };

  if (isLoading) return <div className="flex items-center justify-center h-96"><div className="w-8 h-8 border-4 border-white/10 border-t-blue-500 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-100">Infrastructure Project Monitoring Dashboard</h1>
          </div>
          <p className="text-sm text-slate-400 mt-0.5">Portfolio-wide risk overview and early-warning intelligence</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KpiCard label="Total Projects" value={stats.total} icon={FolderKanban} accent="navy" />
        <KpiCard label="Critical Risk" value={stats.critical} icon={ShieldAlert} accent="red" />
        <KpiCard label="High Risk" value={stats.high} icon={AlertTriangle} accent="orange" />
        <KpiCard label="Medium Risk" value={stats.medium} icon={Activity} accent="amber" />
        <KpiCard label="Cost Risk" value={stats.costRisk} icon={IndianRupee} accent="blue" />
        <KpiCard label="Delay Risk" value={stats.delayRisk} icon={Clock} accent="emerald" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <SectionCard title="Project Risk Overview" subtitle="Distribution across risk levels">
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={riskPie} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={2}>
                {riskPie.map((e, i) => <Cell key={i} fill={e.color} stroke="none" />)}
              </Pie>
              <Tooltip contentStyle={TOOLTIP_STYLE} />
              <Legend verticalAlign="bottom" height={28} wrapperStyle={{ fontSize: 11, color: "#94a3b8" }} />
            </PieChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="Risk by Sector" subtitle="Average AI risk score per sector" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={sectorRisk} margin={{ left: -10, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={GRID} />
              <XAxis dataKey="sector" tick={AXIS} angle={-20} textAnchor="end" height={60} interval={0} />
              <YAxis domain={[0, 100]} tick={AXIS} />
              <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
              <Bar dataKey="avgRisk" radius={[4, 4, 0, 0]}>
                {sectorRisk.map((e, i) => <Cell key={i} fill={e.avgRisk >= 60 ? "#ef4444" : e.avgRisk >= 30 ? "#f59e0b" : "#10b981"} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <SectionCard title="Early Warning Alerts" subtitle={`${warnings.filter(w => w.status === "Active").length} active alerts`}>
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {warnings.slice(0, 6).map((w) => (
              <div key={w.id} className="flex items-start gap-2 p-2 rounded-lg border border-white/10 hover:bg-white/5 cursor-pointer" onClick={() => navigate(`/projects/${w.project_id}`)}>
                <span className={`mt-1 w-2 h-2 rounded-full shrink-0 ${w.severity === "Critical" ? "bg-red-500" : w.severity === "High" ? "bg-orange-500" : "bg-amber-500"}`} />
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-200 truncate">{w.warning_type} — {w.project_name}</div>
                  <div className="text-[11px] text-slate-400 line-clamp-2">{w.description}</div>
                </div>
              </div>
            ))}
            {warnings.length === 0 && <div className="text-sm text-slate-500 text-center py-6">No active warnings</div>}
          </div>
        </SectionCard>

        <SectionCard title="Project Health Overview" subtitle="All monitored projects" className="lg:col-span-2"
          action={
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input value={search} onChange={e => { setSearch(e.target.value); setPage(0); }} placeholder="Filter…" className="pl-7 pr-2 py-1.5 text-xs bg-[#0d1424] border border-white/10 rounded-md text-slate-100 placeholder:text-slate-500 outline-none focus:border-blue-500/50 w-40" />
            </div>
          }
        >
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-left text-slate-400 border-b border-white/10">
                  {[["name", "Project"], ["sector", "Sector"], ["ministry", "Ministry"], ["physical_progress", "Progress"], ["ai_risk_score", "Risk"]].map(([k, l]) => (
                    <th key={k} className="py-2 px-2 font-medium cursor-pointer hover:text-slate-200" onClick={() => toggleSort(k)}>
                      <span className="inline-flex items-center gap-1">{l}{sortKey === k && <ArrowUpDown size={11} />}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paged.map(p => (
                  <tr key={p.id} className="border-b border-white/5 hover:bg-white/5 cursor-pointer" onClick={() => navigate(`/projects/${p.id}`)}>
                    <td className="py-2 px-2 font-medium text-slate-200 max-w-[220px] truncate">{p.name}</td>
                    <td className="py-2 px-2 text-slate-300">{p.sector}</td>
                    <td className="py-2 px-2 text-slate-400 max-w-[150px] truncate">{p.ministry}</td>
                    <td className="py-2 px-2">
                      <div className="flex items-center gap-1.5">
                        <div className="w-12 h-1.5 bg-white/10 rounded-full overflow-hidden">
                          <div className="h-full bg-blue-500" style={{ width: `${p.physical_progress}%` }} />
                        </div>
                        <span className="text-slate-300">{formatPercent(p.physical_progress)}</span>
                      </div>
                    </td>
                    <td className="py-2 px-2"><RiskBadge level={p.risk_level} score={p.ai_risk_score} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between mt-3 text-xs text-slate-400">
            <span>{filtered.length} projects</span>
            <div className="flex gap-1">
              <button disabled={page === 0} onClick={() => setPage(p => p - 1)} className="px-2 py-1 rounded border border-white/10 text-slate-300 disabled:opacity-40 hover:bg-white/5">Prev</button>
              <span className="px-2 py-1 text-slate-400">{page + 1}/{totalPages || 1}</span>
              <button disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)} className="px-2 py-1 rounded border border-white/10 text-slate-300 disabled:opacity-40 hover:bg-white/5">Next</button>
            </div>
          </div>
        </SectionCard>
      </div>
    </div>
  );
}