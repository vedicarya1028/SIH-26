import React, { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Search, Download, RotateCcw, Columns3, ChevronDown } from "lucide-react";
import { useProjects } from "@/hooks/useData";
import RiskBadge from "@/components/ui/RiskBadge";
import { formatCurrency, formatPercent } from "@/lib/format";

const SECTORS = ["Roads", "Railways", "Power", "Renewable Energy", "Water", "Urban Transport", "Telecom", "Ports"];
const RISKS = ["Critical", "High", "Medium", "Low"];

const COLUMNS = [
  { key: "project_code", label: "Code" },
  { key: "name", label: "Project Name" },
  { key: "sector", label: "Sector" },
  { key: "ministry", label: "Ministry" },
  { key: "state", label: "State" },
  { key: "original_cost", label: "Original Cost" },
  { key: "revised_cost", label: "Revised Cost" },
  { key: "expenditure", label: "Expenditure" },
  { key: "physical_progress", label: "Phys. Progress" },
  { key: "original_completion", label: "Original Completion" },
  { key: "revised_completion", label: "Revised Completion" },
  { key: "cost_overrun", label: "Cost Overrun" },
  { key: "time_overrun_months", label: "Time Overrun (mo)" },
  { key: "ai_risk_score", label: "AI Risk" },
  { key: "risk_level", label: "Risk Level" },
];

const inputCls = "px-2 py-1.5 text-xs bg-[#0d1424] border border-white/10 rounded-md text-slate-100 outline-none focus:border-blue-500/50";
const selectCls = "px-2 py-1.5 text-xs bg-[#0d1424] border border-white/10 rounded-md text-slate-200 outline-none focus:border-blue-500/50";

function toCSV(rows, cols) {
  const header = cols.map(c => c.label).join(",");
  const lines = rows.map(r => cols.map(c => {
    const v = r[c.key];
    return `"${String(v ?? "").replace(/"/g, '""')}"`;
  }).join(","));
  return [header, ...lines].join("\n");
}

export default function Projects() {
  const { data: projects = [], isLoading } = useProjects();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();

  const [search, setSearch] = useState(params.get("search") || "");
  const [sector, setSector] = useState("");
  const [ministry, setMinistry] = useState("");
  const [state, setState] = useState("");
  const [risk, setRisk] = useState("");
  const [minCost, setMinCost] = useState("");
  const [page, setPage] = useState(0);
  const [showCols, setShowCols] = useState(false);
  const [visible, setVisible] = useState(Object.fromEntries(COLUMNS.map(c => [c.key, true])));
  const pageSize = 10;

  const ministries = useMemo(() => [...new Set(projects.map(p => p.ministry))].sort(), [projects]);
  const states = useMemo(() => [...new Set(projects.map(p => p.state))].sort(), [projects]);

  const filtered = useMemo(() => {
    return projects.filter(p => {
      if (search && !(p.name.toLowerCase().includes(search.toLowerCase()) || p.project_code.toLowerCase().includes(search.toLowerCase()))) return false;
      if (sector && p.sector !== sector) return false;
      if (ministry && p.ministry !== ministry) return false;
      if (state && p.state !== state) return false;
      if (risk && p.risk_level !== risk) return false;
      if (minCost && p.revised_cost < Number(minCost)) return false;
      return true;
    });
  }, [projects, search, sector, ministry, state, risk, minCost]);

  const paged = filtered.slice(page * pageSize, (page + 1) * pageSize);
  const totalPages = Math.ceil(filtered.length / pageSize);
  const activeCols = COLUMNS.filter(c => visible[c.key]);

  const reset = () => {
    setSearch(""); setSector(""); setMinistry(""); setState(""); setRisk(""); setMinCost(""); setPage(0); setParams({});
  };

  const exportCSV = () => {
    const csv = toCSV(filtered, activeCols);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "nirikshan_projects.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) return <div className="flex items-center justify-center h-96"><div className="w-8 h-8 border-4 border-white/10 border-t-blue-500 rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-100">Projects Explorer</h1>
          </div>
          <p className="text-sm text-slate-400">{filtered.length} of {projects.length} projects</p>
        </div>
        <div className="flex gap-2">
          <button onClick={exportCSV} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-500"><Download size={14} /> Export CSV</button>
          <button onClick={reset} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-white/10 text-slate-300 rounded-lg hover:bg-white/5"><RotateCcw size={14} /> Reset</button>
          <div className="relative">
            <button onClick={() => setShowCols(s => !s)} className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border border-white/10 text-slate-300 rounded-lg hover:bg-white/5"><Columns3 size={14} /> Columns <ChevronDown size={12} /></button>
            {showCols && (
              <div className="absolute right-0 mt-1 w-52 bg-[#111a2e] border border-white/10 rounded-lg shadow-xl p-2 z-20 max-h-72 overflow-y-auto">
                {COLUMNS.map(c => (
                  <label key={c.key} className="flex items-center gap-2 py-1 text-xs text-slate-300 cursor-pointer">
                    <input type="checkbox" checked={visible[c.key]} onChange={(e) => setVisible(v => ({ ...v, [c.key]: e.target.checked }))} />
                    {c.label}
                  </label>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-[#111a2e] rounded-xl border border-white/10 p-3 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
        <div className="relative col-span-2">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(0); }} placeholder="Search name / code" className="w-full pl-8 pr-2 py-1.5 text-xs bg-[#0d1424] border border-white/10 rounded-md text-slate-100 placeholder:text-slate-500 outline-none focus:border-blue-500/50" />
        </div>
        <select value={sector} onChange={e => { setSector(e.target.value); setPage(0); }} className={selectCls}>
          <option value="">All Sectors</option>
          {SECTORS.map(s => <option key={s}>{s}</option>)}
        </select>
        <select value={ministry} onChange={e => { setMinistry(e.target.value); setPage(0); }} className={selectCls}>
          <option value="">All Ministries</option>
          {ministries.map(s => <option key={s}>{s}</option>)}
        </select>
        <select value={state} onChange={e => { setState(e.target.value); setPage(0); }} className={selectCls}>
          <option value="">All States</option>
          {states.map(s => <option key={s}>{s}</option>)}
        </select>
        <select value={risk} onChange={e => { setRisk(e.target.value); setPage(0); }} className={selectCls}>
          <option value="">All Risks</option>
          {RISKS.map(s => <option key={s}>{s}</option>)}
        </select>
        <input type="number" value={minCost} onChange={e => { setMinCost(e.target.value); setPage(0); }} placeholder="Min Cost (Cr)" className={inputCls} />
      </div>

      <div className="bg-[#111a2e] rounded-xl border border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead className="bg-white/[0.03]">
              <tr className="text-left text-slate-400 border-b border-white/10">
                {activeCols.map(c => <th key={c.key} className="py-2.5 px-3 font-semibold whitespace-nowrap">{c.label}</th>)}
              </tr>
            </thead>
            <tbody>
              {paged.map(p => (
                <tr key={p.id} className="border-b border-white/5 hover:bg-white/5 cursor-pointer" onClick={() => navigate(`/projects/${p.id}`)}>
                  {activeCols.map(c => {
                    const v = p[c.key];
                    if (c.key === "risk_level") return <td key={c.key} className="py-2 px-3"><RiskBadge level={v} /></td>;
                    if (c.key === "ai_risk_score") return <td key={c.key} className="py-2 px-3 font-semibold text-slate-200">{v}</td>;
                    if (c.key === "physical_progress") return <td key={c.key} className="py-2 px-3 text-slate-300">{formatPercent(v)}</td>;
                    if (["original_cost", "revised_cost", "expenditure", "cost_overrun"].includes(c.key)) return <td key={c.key} className="py-2 px-3 text-slate-300 whitespace-nowrap">{formatCurrency(v)}</td>;
                    if (c.key === "name") return <td key={c.key} className="py-2 px-3 font-medium text-slate-100 max-w-[260px] truncate" title={v}>{v}</td>;
                    return <td key={c.key} className="py-2 px-3 text-slate-300 whitespace-nowrap">{v}</td>;
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between px-4 py-3 text-xs text-slate-400 border-t border-white/10">
          <span>Showing {paged.length} of {filtered.length}</span>
          <div className="flex gap-1">
            <button disabled={page === 0} onClick={() => setPage(p => p - 1)} className="px-2.5 py-1 rounded border border-white/10 text-slate-300 disabled:opacity-40 hover:bg-white/5">Prev</button>
            <span className="px-2 py-1 text-slate-400">{page + 1}/{totalPages || 1}</span>
            <button disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)} className="px-2.5 py-1 rounded border border-white/10 text-slate-300 disabled:opacity-40 hover:bg-white/5">Next</button>
          </div>
        </div>
      </div>
    </div>
  );
}