import React from "react";
import { useNavigate } from "react-router-dom";
import Logo from "@/components/Logo";

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0b1120] flex flex-col items-center justify-center px-6">
      <div className="max-w-xl text-center">
        <div className="flex justify-center mb-6">
          <Logo size={56} />
        </div>
        <h1 className="text-3xl font-bold tracking-wide text-slate-100">NIRIKSHAN AI</h1>
        <p className="mt-2 text-sm font-medium uppercase tracking-[0.2em] text-blue-400">Predict. Monitor. Act.</p>
        <p className="mt-6 text-sm leading-relaxed text-slate-400">
          An intelligent infrastructure project monitoring platform that helps identify project risks early,
          understand their causes and prioritize timely action.
        </p>
        <button
          onClick={() => navigate("/dashboard")}
          className="mt-8 inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold rounded-lg transition-colors"
        >
          Open Dashboard
        </button>
      </div>

    </div>
  );
}