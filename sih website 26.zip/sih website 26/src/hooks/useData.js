import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export function useProjects() {
  return useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const all = [];
      let skip = 0;
      while (true) {
        const batch = await base44.entities.Project.list("-ai_risk_score", 100, skip);
        all.push(...batch);
        if (batch.length < 100) break;
        skip += 100;
      }
      return all;
    },
  });
}

export function useProject(id) {
  return useQuery({
    queryKey: ["project", id],
    queryFn: async () => {
      if (!id) return null;
      return await base44.entities.Project.get(id);
    },
    enabled: !!id,
  });
}

export function useProjectUpdates(projectId) {
  return useQuery({
    queryKey: ["projectUpdates", projectId],
    queryFn: async () => {
      if (!projectId) return [];
      const res = await base44.entities.ProjectUpdate.filter({ project_id: projectId }, "date", 100);
      return res;
    },
    enabled: !!projectId,
  });
}

export function useRiskAssessment(projectId) {
  return useQuery({
    queryKey: ["riskAssessment", projectId],
    queryFn: async () => {
      if (!projectId) return null;
      const res = await base44.entities.RiskAssessment.filter({ project_id: projectId }, "-timestamp", 5);
      return res[0] || null;
    },
    enabled: !!projectId,
  });
}

export function useEarlyWarnings(projectId) {
  return useQuery({
    queryKey: ["earlyWarnings", projectId],
    queryFn: async () => {
      const filter = projectId ? { project_id: projectId } : {};
      const res = await base44.entities.EarlyWarning.filter(filter, "-date", 200);
      return res;
    },
  });
}

export function useDataSources() {
  return useQuery({
    queryKey: ["dataSources"],
    queryFn: async () => await base44.entities.DataSource.list(),
  });
}