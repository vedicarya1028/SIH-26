import React from "react";

export default function DemoBadge({ className = "" }) {
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold tracking-wide bg-amber-500/15 text-amber-400 border border-amber-500/30 ${className}`}>
      DEMO DATA
    </span>
  );
}

export function SihTag() {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold tracking-wide bg-white/10 text-slate-300 border border-white/10">
      STUDENT DEMO • SIH 2026
    </span>
  );
}