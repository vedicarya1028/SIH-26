import React from "react";
import { riskColor } from "@/lib/format";

export default function RiskBadge({ level, score }) {
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-semibold border ${riskColor(level)}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${level === "Critical" ? "bg-red-500" : level === "High" ? "bg-orange-500" : level === "Medium" ? "bg-amber-500" : "bg-emerald-500"}`} />
      {level}{score != null && ` · ${score}`}
    </span>
  );
}