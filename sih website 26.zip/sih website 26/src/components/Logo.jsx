import React from "react";

export default function Logo({ size = 36, className = "" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" className={className} aria-label="NIRIKSHAN AI logo">
      <rect x="2" y="2" width="44" height="44" rx="10" fill="#0B1F3A" />
      {/* radar rings */}
      <circle cx="24" cy="24" r="16" stroke="#3B82F6" strokeWidth="1.4" opacity="0.5" />
      <circle cx="24" cy="24" r="10" stroke="#10B981" strokeWidth="1.4" opacity="0.7" />
      <circle cx="24" cy="24" r="4" fill="#10B981" />
      {/* radar sweep */}
      <path d="M24 24 L40 14 A19 19 0 0 0 24 5 Z" fill="#3B82F6" opacity="0.25" />
      {/* bar chart base */}
      <rect x="8" y="34" width="4" height="6" rx="1" fill="#60A5FA" />
      <rect x="14" y="30" width="4" height="10" rx="1" fill="#60A5FA" />
      <rect x="20" y="36" width="4" height="4" rx="1" fill="#60A5FA" />
      {/* crosshair */}
      <line x1="24" y1="6" x2="24" y2="42" stroke="#1E3A5F" strokeWidth="0.8" opacity="0.4" />
      <line x1="6" y1="24" x2="42" y2="24" stroke="#1E3A5F" strokeWidth="0.8" opacity="0.4" />
    </svg>
  );
}