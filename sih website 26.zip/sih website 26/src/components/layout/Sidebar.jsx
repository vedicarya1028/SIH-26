import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { LayoutDashboard, FolderKanban, FileText, ShieldAlert, BarChart3, Bot, Info, ChevronLeft, X } from "lucide-react";
import Logo from "@/components/Logo";

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/projects", label: "Projects", icon: FolderKanban },
  { to: "/projects/:id", label: "Project Details", icon: FileText, hidden: true },
  { to: "/risk", label: "Risk & Early Warnings", icon: ShieldAlert },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/assistant", label: "AI Assistant", icon: Bot },
  { to: "/about", label: "About", icon: Info },
];

export default function Sidebar({ collapsed, setCollapsed, mobileOpen, setMobileOpen }) {
  return (
    <>
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/40 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}
      <aside
        className={`fixed lg:static top-0 left-0 h-screen z-50 flex flex-col bg-[#0B1F3A] text-slate-200 transition-all duration-300 ${
          collapsed ? "w-20" : "w-64"
        } ${mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}
      >
        <div className="flex items-center gap-3 px-4 h-16 border-b border-white/10 shrink-0">
          <Logo size={36} />
          {!collapsed && (
            <div className="leading-tight">
              <div className="font-bold text-white tracking-wide text-[15px]">NIRIKSHAN AI</div>
              <div className="text-[10px] text-blue-300/80 uppercase tracking-[0.15em]">Predict. Monitor. Act.</div>
            </div>
          )}
          <button className="ml-auto lg:hidden text-slate-400" onClick={() => setMobileOpen(false)}>
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 py-3 overflow-y-auto">
          {nav.filter(n => !n.hidden).map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 mx-2 my-0.5 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                  isActive
                    ? "bg-blue-600/90 text-white font-medium shadow-sm"
                    : "text-slate-300 hover:bg-white/10 hover:text-white"
                }`
              }
            >
              <item.icon size={18} className="shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        <div className="px-3 py-3 border-t border-white/10 shrink-0">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="hidden lg:flex items-center justify-center w-full gap-2 text-xs text-slate-400 hover:text-white py-1.5 rounded hover:bg-white/10"
          >
            <ChevronLeft size={14} className={`transition-transform ${collapsed ? "rotate-180" : ""}`} />
            {!collapsed && "Collapse"}
          </button>
        </div>
      </aside>
    </>
  );
}