import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Search, Bell, Menu, Clock, ChevronDown, LogOut, LayoutDashboard, BarChart3, Info, ShieldAlert } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useEarlyWarnings } from "@/hooks/useData";

export default function TopBar({ setMobileOpen, lastUpdated }) {
  const [q, setQ] = useState("");
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const navigate = useNavigate();
  const notifRef = useRef(null);
  const profileRef = useRef(null);
  const { data: warnings = [] } = useEarlyWarnings();
  const active = warnings.filter(w => w.status === "Active");

  useEffect(() => {
    const handler = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setNotifOpen(false);
      if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const onSearch = (e) => {
    e.preventDefault();
    if (q.trim()) {
      navigate(`/projects?search=${encodeURIComponent(q.trim())}`);
      setQ("");
    }
  };

  const logout = async () => {
    setProfileOpen(false);
    try { await base44.auth.logout(); } catch (e) { /* ignore */ }
    window.location.href = "/";
  };

  const go = (path) => { setProfileOpen(false); navigate(path); };

  return (
    <header className="sticky top-0 z-30 h-16 bg-[#0b1120]/90 backdrop-blur border-b border-white/10 flex items-center gap-3 px-4 lg:px-6">
      <button className="lg:hidden text-slate-300" onClick={() => setMobileOpen(true)}>
        <Menu size={22} />
      </button>

      <form onSubmit={onSearch} className="relative flex-1 max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search projects, sectors, states…"
          className="w-full pl-9 pr-3 py-2 text-sm bg-[#0d1424] border border-white/10 rounded-lg text-slate-100 placeholder:text-slate-500 focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 outline-none transition"
        />
      </form>

      <div className="hidden lg:flex items-center gap-1.5 text-xs text-slate-400">
        <Clock size={14} />
        <span>Updated {lastUpdated}</span>
      </div>

      {/* Notifications */}
      <div className="relative" ref={notifRef}>
        <button onClick={() => setNotifOpen(o => !o)} className="relative p-2 text-slate-400 hover:text-slate-200 hover:bg-white/5 rounded-lg">
          <Bell size={18} />
          {active.length > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />}
        </button>
        {notifOpen && (
          <div className="absolute right-0 mt-2 w-80 bg-[#111a2e] border border-white/10 rounded-xl shadow-2xl z-50 overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
              <span className="text-sm font-semibold text-slate-100">Notifications</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/15 text-red-400 font-medium">{active.length} active</span>
            </div>
            <div className="max-h-80 overflow-y-auto">
              {active.slice(0, 6).map(w => (
                <button key={w.id} onClick={() => { setNotifOpen(false); navigate(`/projects/${w.project_id}`); }} className="w-full text-left flex gap-2 px-4 py-2.5 hover:bg-white/5 border-b border-white/5">
                  <span className={`mt-1 w-2 h-2 rounded-full shrink-0 ${w.severity === "Critical" ? "bg-red-500" : w.severity === "High" ? "bg-orange-500" : "bg-amber-500"}`} />
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-slate-200 truncate">{w.warning_type}</div>
                    <div className="text-[11px] text-slate-400 truncate">{w.project_name}</div>
                  </div>
                </button>
              ))}
              {active.length === 0 && <div className="text-sm text-slate-500 text-center py-8">No active notifications</div>}
            </div>
            <button onClick={() => { setNotifOpen(false); navigate("/risk"); }} className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-medium text-blue-400 hover:bg-blue-500/10 border-t border-white/10">
              <ShieldAlert size={14} /> View all warnings
            </button>
          </div>
        )}
      </div>

      {/* Profile */}
      <div className="relative" ref={profileRef}>
        <button onClick={() => setProfileOpen(o => !o)} className="flex items-center gap-2 pl-2 border-l border-white/10 py-1 hover:bg-white/5 rounded-lg">
          <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold">NA</div>
          <div className="hidden md:block leading-tight text-left">
            <div className="text-xs font-semibold text-slate-200">Admin User</div>
            <div className="text-[10px] text-slate-500">Portfolio Manager</div>
          </div>
          <ChevronDown size={14} className="hidden md:block text-slate-500" />
        </button>
        {profileOpen && (
          <div className="absolute right-0 mt-2 w-52 bg-[#111a2e] border border-white/10 rounded-xl shadow-2xl z-50 py-1">
            <button onClick={() => go("/dashboard")} className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:bg-white/5 hover:text-white">
              <LayoutDashboard size={15} /> Dashboard
            </button>
            <button onClick={() => go("/analytics")} className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:bg-white/5 hover:text-white">
              <BarChart3 size={15} /> Analytics
            </button>
            <button onClick={() => go("/about")} className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:bg-white/5 hover:text-white">
              <Info size={15} /> About
            </button>
            <div className="border-t border-white/10 my-1" />
            <button onClick={logout} className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-red-400 hover:bg-red-500/10">
              <LogOut size={15} /> Logout
            </button>
          </div>
        )}
      </div>
    </header>
  );
}